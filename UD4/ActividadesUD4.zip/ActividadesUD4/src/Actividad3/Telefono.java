public class Telefono {
    private String valor;

    public Telefono(String valor) {
        this.valor = valor;
    }

    @Override
    public String toString() {
        return valor;
    }
}
