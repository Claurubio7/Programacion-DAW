package Actividad4;

public class VersionExtra {
    private Version version;
    private Extra extra;
    private double precio;

    public VersionExtra(Version version, Extra extra, double precio) {
        this.version = version;
        this.extra = extra;
        this.precio = precio;
    }
}

