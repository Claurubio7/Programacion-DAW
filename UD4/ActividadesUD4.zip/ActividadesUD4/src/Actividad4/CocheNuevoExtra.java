package Actividad4;

public class CocheNuevoExtra {
    private CocheNuevo cocheNuevo;
    private Extra extra;

    public CocheNuevoExtra(CocheNuevo cocheNuevo, Extra extra) {
        this.cocheNuevo = cocheNuevo;
        this.extra = extra;
    }
}
