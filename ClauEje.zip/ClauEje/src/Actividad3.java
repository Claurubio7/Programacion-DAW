import java.util.Scanner;

public class Actividad3 {
    /*PÁG 14
    Actividad: Haz un programa que nos pide una nota y nos indica la calificación
    (sobresaliente, notable, bien, aprobado, suspenso, nota incorrecta). Usa if-else y switch */

    public static void main(String[] args) {
        //Introducir la nota
        Scanner sc=new Scanner(System.in);
        System.out.print("Introduce la nota: ");
        int nota=sc.nextInt();

        if(nota>=0 && nota <5){
            System.out.println("SUSPENSO");
        }
        else if (nota>=5 && nota<7){
            System.out.println("APROBADO");
        }
        else if(nota>=7 && nota <9){
            System.out.println("NOTABLE");
        }
        else if(nota>=9 && nota <=10){
            System.out.println("SOBRESALIENTE");
        }
        else{
            System.out.println("Nota incorrecta");
        }

        // Calificación usando switch (otra forma de hacerlo)
        switch(nota){
            case 0:
            case 1:
            case 2:
            case 3:
            case 4: System.out.println("SUSPENSO");break;
            case 5:
            case 6: System.out.println("APROBADO");break;
            case 7:
            case 8: System.out.println("NOTABLE");break;
            case 9:
            case 10: System.out.println("SOBRESALIENTE");break;
            default:System.out.println("Nota incorrecta");break;
        }
    }
}
