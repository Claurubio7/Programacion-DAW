import java.util.Scanner;

public class Actividad2 {
    /* Pág 14
     Actividad2: Haz el programa JAVA del siguiente diagrama de flujo */

     public static void main(String[] args) {
        // Resolución de una ecuación de segundo grado: ax² + bx + c = 0
        int a = 0, b = 0, c = 0;
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce los valores de a b c: ");
        a = sc.nextInt();
        b = sc.nextInt();
        c = sc.nextInt();

        double x1 = 0, x2 = 0;
        // Calcular el discriminante (b² - 4ac)
        double discriminante=Math.pow(b,2)-4*a*c;

        if (discriminante <0){
            System.out.println("No hay soluciones");
        }
        else if(discriminante == 0){
            // Solo hay una solución
            x1=-b/(2*a);
            System.out.println("La única solución es: "+x1);
        }
        else{
            // Hay dos soluciones posibles
            x1=(-b+Math.sqrt(discriminante))/(2*a);
            x2=(-b-Math.sqrt(discriminante))/(2*a);
            System.out.println("La solución 1 es: "+x1);
            System.out.println("La solución 2 es: "+x2);
        }
    }
}
