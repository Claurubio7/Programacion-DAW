package Funciones.Recursividad;

public class Actividad18 {
    /*Método recursivo para pasar un número decimal, que
    compruebe que es positivo, y pasarlo a binario mediante
    sucesivas divisiones por 2 */

    public static int pasarBinario (int numero) {
        if (numero == 0) {
            return 0; 
        } else {
            return (numero % 2) + 10 * pasarBinario(numero / 2);
        }
    }

    public static void main(String[] args) {
        System.out.println(pasarBinario(50));
    }
}
