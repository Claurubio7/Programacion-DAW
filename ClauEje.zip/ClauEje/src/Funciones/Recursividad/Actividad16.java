package Funciones.Recursividad;

public class Actividad16 {
    /*Función que devuelve la suma de los números naturales desde 1
    hasta N. Compara el código con el que se obtendría iterativo */

    // Con Recursividad
    public static int sumaRecursividad(int numero) {
        if (numero <= 1) {
            return numero;
        } else
            return numero + sumaRecursividad(numero-1);
    }

    // Con iteracion
    public static int sumaIteracion(int numero) {
        int suma = 0;
        for(int i = 1; i <= numero; i++) {
            suma += i;
        }
        return suma;
    }

    public static void main(String[] args) {
        System.out.println(sumaRecursividad(5));
        System.out.println(sumaIteracion(5));
    }
}
