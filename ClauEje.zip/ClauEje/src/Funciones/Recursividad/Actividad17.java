package Funciones.Recursividad;

public class Actividad17 {
    /*Función que calcula ab
 usando recursividad. Recordad que a^b=a*a^b-1 */

 public static int multiplicarBVeces(int a, int b) {
        if(b <= 0) {
            return 1;
        } else {
            return a * multiplicarBVeces(a, b-1);
        }

    }

    public static void main(String[] args) {
        System.out.println(multiplicarBVeces(4, 3));
    }

}
