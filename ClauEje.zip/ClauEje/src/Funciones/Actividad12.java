package Funciones;

public class Actividad12 {
    /*PÁG 22
    Calcular el máximo de 3 números si existe la función maximo(a,b).
    Después aplica ambas para el caso de máximo de 5 números. Ten en cuenta que
    una función se puede utilizar en una expresión Ej: int a= 5+maximo(3,7); o int
    b=maximo(maximo(2,3),4); */

    public static int maximo(int a, int b) {
        int maximo = 0;
        if(a > b) {
            maximo = a;
        } else if (b > a) {
            maximo = b;
        }
        return maximo;
    }

    public static void main(String[] args) {
        // Maximo de 3 numeros
        System.out.println(maximo(7, maximo(5, 2)));
        // Maximo de 5 numeros
        System.out.println(maximo(5, maximo(10, maximo(7, maximo(5, 40)))));
    }
}
