package Bucles;

import java.util.Scanner;

public class Actividad7 {
    /* PÁG 16
    3)Desarrolla un programa que muestre la edad máxima y mínima de un grupo de alumnos que se
    introduzca hasta escribir -1 
    
    PÁG 17
    4)Continúa el programa anterior para que calcule la suma,
    media, número de alumnos y cuántos son mayores de
    edad*/

    public static void main(String[] args) {
        //Leer edades hasta -1 y entonces sacar el valor máximo y mínimo

        int maximo = -1;
        int minimo = 1000000;
        int contadorPersona = 0;
        int suma = 0;
        int mayor18 = 0;

        Scanner sc = new Scanner(System.in);
        int edad;

        do {
            System.out.print("Introduce una edad o -1 para salir: ");
            edad = sc.nextInt();

            if (edad != -1) {
                contadorPersona++;//Nueva persona
                suma += edad;//suma=suma+edad;

                if (edad > maximo) maximo = edad;
                if (edad < minimo) minimo = edad;
                if (edad >= 18) mayor18++;
            }

        } while (edad != -1);
        //Actividad3 máximo y minimo
        System.out.println("El máximo es: "+maximo);
        System.out.println("El mínimo es: "+minimo);
        //Actividad4 suma , media, numero d ealumnos, mayor de edad
        System.out.println("El número de personas: "+contadorPersona);
        System.out.println("El número de mayores de 18: "+mayor18);
        System.out.println("Suma de edades: "+suma);
        System.out.println("Media de edades: "+(suma/contadorPersona));
    }
}
