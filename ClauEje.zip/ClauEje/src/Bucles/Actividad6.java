package Bucles;

import java.util.Scanner;

public class Actividad6 {
    /*PÁG 16
    Desarrolla un programa que calcule el factorial del
    número introducido. Ej: 4!= 4*3*2*1 */

    public static void main(String[] args) {
        // Calcular el factorial de un número 
        Scanner sc = new Scanner(System.in);
        System.out.print("Introduce un número: ");
        int numero = sc.nextInt();

        int producto = 1;
        for (int i = 1; i <= numero; i++) {
            producto = producto * i;
        }

        System.out.println("El factorial de " + numero + " es: " + producto);
    }
}
