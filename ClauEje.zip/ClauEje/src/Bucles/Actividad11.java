package Bucles;

public class Actividad11 {
    /*PÁG 19
     * Desarrolla el programa que
    muestra las tablas de multiplicar del 1 al 10*/

    public static void main(String[] args) {
        for(int i = 1; i <= 10; i++){
            System.out.println("Tabla del " + i);
            for (int j = 1; j<= 10; j++) {
                int resultado = i * j;
                System.out.println(i + " * " + j + " = " + resultado);
            }
        }
    }
}
