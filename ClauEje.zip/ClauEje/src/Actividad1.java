public class Actividad1 {

    public static void main(String[] args) {
        
        //Tema 2, actividad pág 9
        /*
        * Actividad1: Realiza un programa que genera 2 números y nos diga el cociente, la
        * media, la potencia y la raíz cuadrada. Usa tipos adecuados
        */

        /*
         * Pseudocódigo
         * INICIO
         *  generar nº1 aleatorio
         *  generar nº1 aleatorio
         *  Hacer calculos --> cociente, media, potencia, raiz cuadrada
         *  Imprimir el resultado
         * FIN
         */

         //Generar nº aleatorios
         int min=1; int max=10;
         int numero1= (int)(Math.random()*(max-min+1)) + min;
         int numero2= (int)(Math.random()*(max-min+1)) + min;
         /*
          * Math.random() = 0.999999--> 0.999999 * 10 ≈ 9.99999 
          * → (int)9.99999 = 9 
          * → 9 + 1 = 10 → numero = 10
          */


          //Hacer calculos
          double cociente= numero1/(double)numero2;
          double media= (numero1+numero2)/2.0;
          double potencia = Math.pow(numero1, numero2);
          double raiz1= Math.sqrt(numero1);
          double raiz2= Math.sqrt(numero2);

          //Sacar resultados
          System.out.println("Los números generados son: " + numero1 + " "+ numero2);
          System.out.println(cociente);
          System.out.println("La media es: "+ media);
          System.out.println("La potencia es: "+ potencia);
          System.out.println("La raiz de el número 1 es: "+ raiz1);
          System.out.println("La raiz de el número 2 es: "+ raiz2);


    }
}

